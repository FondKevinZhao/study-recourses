// app.js
App({
  globalData:{
    msg:"我是全局初始化的数据",
    audioId:null,
    playState:false
  }
})
